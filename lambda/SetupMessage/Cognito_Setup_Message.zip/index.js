const jwtDecode = require("jwt-decode");
const ProjectName = process.env.PROJECT_NAME;
const SupportGrpName = process.env.SUPPORT_GROUP_NAME;
const SupportGrpContact = process.env.SUPPORT_GROUP_CONTACT;

const ResponseHeaders = {
  "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGIN,
};

exports.handler = async (event) => {
  try {
    const id_token = event.headers[process.env.AUTHORIZATION_HEADER_NAME];
    const decoded = jwtDecode(id_token);

    const data = {
      ProjectName: ProjectName,
      Name: decoded.name,
      Email: decoded.email,
      SupportGroupName: SupportGrpName,
      SupportGroupContact: SupportGrpContact,
    };
    return {
      statusCode: 200,
      headers: ResponseHeaders,
      body: JSON.stringify(data),
    };
  } catch (err) {
    console.log("Error", err);
    return {
      statusCode: 500,
      headers: ResponseHeaders,
      body: JSON.stringify({
        error: "Exception",
        message: "Server Error",
      }),
    };
  }
};
