const fetch = require("node-fetch");

const appUrl = process.env.ALLOWED_ORIGIN;
const ResponseHeaders = {
  "Access-Control-Allow-Origin": appUrl
};

exports.handler = async (event, context) => {
  const sessionToken = event.body;

  if (sessionToken === null) {
    return {statusCode: 500,};
  }

  const url = `https://signin.aws.amazon.com/federation?Action=getSigninToken&Session=${sessionToken}`;

  const res = await fetch(url);
  const body = await res.json();

  const Tokentest = body.SigninToken;
  if (Tokentest !== null) {
    return {
      statusCode: 200,
      headers: ResponseHeaders,
      body: JSON.stringify(body),
    };
  } else {
    return {
      statusCode: 500,
      headers: ResponseHeaders,
      body: JSON.stringify({
        error: "Exception",
        message: "Server Error",
      }),
    };
  }
};
