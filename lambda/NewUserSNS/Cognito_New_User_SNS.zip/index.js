const AWS = require("aws-sdk");
AWS.config.region = process.env.AWS_REGION;
const TOPIC_ARN = process.env.TOPIC_ARN;
const dateNow = Date.now();

const CreateDate =
  new Date(dateNow).toLocaleDateString("en-US") +
  " " +
  new Date(dateNow).toLocaleTimeString("en-US");

exports.handler = async (event) => {
  const identities = JSON.parse(event.request.userAttributes.identities);
  const message = `
     Cognito DisplayName: ${event.request.userAttributes.name}
     Cognito Email: ${event.request.userAttributes.email}
     Cognito CreateDate: ${CreateDate}
     Cognito Subject Name: ${event.request.userAttributes.sub}
     Cognito UserName: ${event.userName}
     Cognito UserPoolId: ${event.userPoolId}

        Identities:
            Identity Provider UserID: ${identities[0].userId}
            ProviderName: ${identities[0].providerName}
            ProviderType: ${identities[0].providerType}
      `;

  var params = {
    Subject: `New user: ${event.request.userAttributes.name} (${event.request.userAttributes.email})`,
    Message: message,
    TopicArn: TOPIC_ARN,
  };

  // Create promise and SNS service object
  const sns = new AWS.SNS({ apiVersion: "2010-03-31" });
  const publishTextPromise = await sns.publish(params).promise();

  console.log(
    `Message ${params.Message} send sent to the topic ${params.TopicArn}`
  );
  console.log("MessageID is " + publishTextPromise.MessageId);

  return event;
};
