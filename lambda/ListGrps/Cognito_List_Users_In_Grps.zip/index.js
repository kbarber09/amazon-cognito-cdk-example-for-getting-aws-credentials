const AWS = require("aws-sdk");
const jwtDecode = require("jwt-decode");

AWS.config.region = process.env.AWS_REGION;

const ResponseHeaders = {
  "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGIN
};

const UserPoolId =process.env.COGNITO_USER_POOL_ID
const cognitoISP = new AWS.CognitoIdentityServiceProvider();

exports.handler = async (event) => {
  try {
    const id_token = event.headers[process.env.AUTHORIZATION_HEADER_NAME];
    const decoded = jwtDecode(id_token);

    const userSub = decoded.sub;
    const userParams = {
      UserPoolId,
      Filter: 'sub="' + userSub + '"',
      Limit: 1,
    };

    const users = await cognitoISP.listUsers(userParams).promise();
    const Username = users.Users[0].Username;

    const data = await cognitoISP
      .adminListGroupsForUser({
        UserPoolId,
        Username,
      })
      .promise();

    const groups = data.Groups;

    return {
      statusCode: 200,
      headers: ResponseHeaders,
      body: JSON.stringify(groups),
    };
  } catch (err) {
    console.log("Error", err);
    return {
      statusCode: 500,
      headers: ResponseHeaders,
      body: JSON.stringify({
        error: "Exception",
        message: "Server Error",
      }),
    };
  }
};

